import express from "express";
import path from "path";
import helmet from "helmet";
import cors from "cors";
import multer from "multer";
import { createServer as createViteServer } from "vite";
import { db } from "./src/db/index";
import { settings, stock, customers, receipts, orders, sales, odf, users, rolesPermissions, auditLogs } from "./src/db/schema";
import { eq, or, ilike, and, sql } from "drizzle-orm";
import { authenticateToken, checkPermission } from "./src/middleware/auth";
import { auditLogger } from "./src/middleware/audit";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Security Middleware
  app.use(helmet({
    contentSecurityPolicy: false, // Disable CSP for Vite dev server compatibility
  }));
  app.use(cors());

  // Static folder for uploads
  const fs = await import("fs");
  if (!fs.existsSync("uploads")) {
    fs.mkdirSync("uploads");
  }
  app.use('/uploads', express.static('uploads'));

  // Multer setup
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}-${file.originalname}`);
    },
  });
  const upload = multer({ storage });

  // JSON middleware
  app.use(express.json());

  // Audit Logging Middleware
  app.use(auditLogger);

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // --- Auth Endpoints ---
  app.post("/api/login", async (req, res) => {
    const { username, password } = req.body;
    const { default: bcrypt } = await import("bcryptjs");
    const { default: jwt } = await import("jsonwebtoken");
    const JWT_SECRET = process.env.JWT_SECRET || "your-default-secret";

    try {
      const userArr = await db.select().from(users).where(eq(users.username, username)).limit(1);
      if (userArr.length === 0) return res.status(401).json({ error: "Invalid username or password" });
      const user = userArr[0];

      const isMatch = await bcrypt.compare(password, user.passwordHash);
      if (!isMatch) return res.status(401).json({ error: "Invalid username or password" });

      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role },
        JWT_SECRET,
        { expiresIn: "12h" }
      );

      res.json({
        token,
        user: { id: user.id, username: user.username, role: user.role }
      });
    } catch (error) {
      console.error("Login Error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  // --- User Management Endpoints (Admin Only) ---
  app.get("/api/users", authenticateToken, async (req: any, res) => {
    if (req.user?.role !== 'Admin') return res.status(403).json({ error: "Admin access required" });
    try {
      const allUsers = await db.select({
        id: users.id,
        username: users.username,
        email: users.email,
        role: users.role,
        createdAt: users.createdAt
      }).from(users);
      res.json(allUsers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.post("/api/users", authenticateToken, async (req: any, res) => {
    if (req.user?.role !== 'Admin') return res.status(403).json({ error: "Admin access required" });
    const { username, email, password, role } = req.body;
    const { default: bcrypt } = await import("bcryptjs");

    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = await db.insert(users).values({
        username,
        email,
        passwordHash: hashedPassword,
        role: role || 'User'
      }).returning();
      
      res.status(201).json(newUser[0]);
    } catch (error) {
      console.error("User Creation Error:", error);
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  app.get("/api/users/:id/permissions", authenticateToken, async (req: any, res) => {
    if (req.user?.role !== 'Admin') return res.status(403).json({ error: "Admin access required" });
    try {
      const permissions = await db.select().from(rolesPermissions).where(eq(rolesPermissions.userId, parseInt(req.params.id)));
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch permissions" });
    }
  });

  app.put("/api/users/:id/permissions", authenticateToken, async (req: any, res) => {
    if (req.user?.role !== 'Admin') return res.status(403).json({ error: "Admin access required" });
    const { permissions } = req.body; // Array of { functionality, canView, canCreate, canEdit, canDelete }
    const userId = parseInt(req.params.id);

    try {
      await db.transaction(async (tx) => {
        // Simple approach: delete existing and re-insert
        await tx.delete(rolesPermissions).where(eq(rolesPermissions.userId, userId));
        if (permissions && permissions.length > 0) {
          await tx.insert(rolesPermissions).values(
            permissions.map((p: any) => ({
              userId,
              functionality: p.functionality,
              canView: p.canView || false,
              canCreate: p.canCreate || false,
              canEdit: p.canEdit || false,
              canDelete: p.canDelete || false
            }))
          );
        }
      });
      res.json({ message: "Permissions updated successfully" });
    } catch (error) {
      console.error("Permission Update Error:", error);
      res.status(500).json({ error: "Failed to update permissions" });
    }
  });

  // --- Sales Recording Endpoint ---
  app.post("/api/sales", authenticateToken, checkPermission('sales', 'create'), async (req, res) => {
    const { customerId, barcode, paymentMode, chequeNumber, qty, amount, unitSalesPrice, itemDetails } = req.body;

    try {
      const result = await db.transaction(async (tx) => {
        // 1. Fetch item from stock to verify and get details
        const stockItems = await tx.select().from(stock).where(eq(stock.barcode, barcode)).limit(1);
        if (stockItems.length === 0) {
          throw new Error("Item not found in stock or already sold");
        }
        const item = stockItems[0];

        // 2. Calculate VAT (15%)
        const vat = Number(amount) * 0.15;

        // 3. Record the sale
        const newSale = await tx.insert(sales).values({
          customerId,
          stockId: item.id,
          paymentMode,
          chequeNumber,
          qty,
          itemDetails: itemDetails || item.subCategory,
          weight: item.weightGrams,
          fineness: item.fineness,
          unitSalesPrice: unitSalesPrice.toString(),
          amount: amount.toString(),
          vat15: vat.toFixed(2),
          metalType: item.metalType,
        }).returning();

        // 4. Deduct from stock (remove the unique item)
        await tx.delete(stock).where(eq(stock.id, item.id));

        return newSale[0];
      });

      res.status(201).json({ sales_id: result.id, sale: result });
    } catch (error: any) {
      console.error("Sales Recording Error:", error);
      const status = error.message === "Item not found in stock or already sold" ? 404 : 500;
      res.status(status).json({ error: error.message || "Failed to record sale" });
    }
  });

  // --- Stock Endpoints ---
  app.get("/api/stock/metadata", authenticateToken, async (req, res) => {
    try {
      const meta = await db.select().from(settings).where(ilike(settings.key, 'stock_%'));
      const guarantee = await db.select().from(settings).where(eq(settings.key, 'guarantee_options')).limit(1);
      res.json([...meta, ...guarantee]);
    } catch (error) {
      console.error("Stock Metadata Error:", error);
      res.status(500).json({ error: "Failed to fetch stock metadata" });
    }
  });

  app.get("/api/stock", authenticateToken, checkPermission('stock', 'view'), async (req, res) => {
    try {
      const items = await db.select().from(stock);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stock" });
    }
  });

  app.get("/api/stock/:barcode", authenticateToken, checkPermission('stock', 'view'), async (req, res) => {
    try {
      const item = await db.select().from(stock).where(eq(stock.barcode, req.params.barcode)).limit(1);
      if (item.length === 0) return res.status(404).json({ error: "Stock item not found" });
      res.json(item[0]);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stock item" });
    }
  });

  app.post("/api/stock", authenticateToken, checkPermission('stock', 'create'), async (req, res) => {
    try {
      const newItem = await db.insert(stock).values(req.body).returning();
      res.status(201).json(newItem[0]);
    } catch (error) {
      res.status(500).json({ error: "Failed to create stock item" });
    }
  });

  app.put("/api/stock/:id", authenticateToken, checkPermission('stock', 'edit'), async (req, res) => {
    try {
      const updated = await db.update(stock)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(stock.id, parseInt(req.params.id)))
        .returning();
      if (updated.length === 0) return res.status(404).json({ error: "Stock item not found" });
      res.json(updated[0]);
    } catch (error) {
      res.status(500).json({ error: "Failed to update stock item" });
    }
  });

  app.delete("/api/stock/:id", authenticateToken, checkPermission('stock', 'delete'), async (req, res) => {
    try {
      await db.delete(stock).where(eq(stock.id, parseInt(req.params.id)));
      res.json({ message: "Stock item deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete stock item" });
    }
  });

  // --- KYC / Customer Endpoints ---
  app.get("/api/customers", authenticateToken, checkPermission('customers', 'view'), async (req, res) => {
    const { search } = req.query;
    try {
      let query = db.select().from(customers);
      if (search) {
        const searchStr = `%${search}%`;
        // Use a conditional or if search is provided
        // Drizzle ilike needs to be handled
        const results = await db.select().from(customers).where(
          or(
            ilike(customers.name, searchStr),
            ilike(customers.idNumber, searchStr)
          )
        );
        return res.json(results);
      }
      const allCustomers = await query;
      res.json(allCustomers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customers" });
    }
  });

  app.post("/api/customers", authenticateToken, checkPermission('customers', 'create'), async (req, res) => {
    try {
      const newCustomer = await db.insert(customers).values(req.body).returning();
      res.status(201).json(newCustomer[0]);
    } catch (error) {
      res.status(500).json({ error: "Failed to create customer profile" });
    }
  });

  app.put("/api/customers/:id", authenticateToken, checkPermission('customers', 'edit'), async (req, res) => {
    try {
      const updated = await db.update(customers)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(customers.id, parseInt(req.params.id)))
        .returning();
      if (updated.length === 0) return res.status(404).json({ error: "Customer not found" });
      res.json(updated[0]);
    } catch (error) {
      res.status(500).json({ error: "Failed to update customer" });
    }
  });

  app.get("/api/customers/:id/history", authenticateToken, checkPermission('customers', 'view'), async (req, res) => {
    const customerId = parseInt(req.params.id);
    try {
      const [customerReceipts, customerOrders, customerOdfs] = await Promise.all([
        db.select({
          id: receipts.id,
          receiptNo: receipts.receiptSerialNumber,
          date: receipts.createdAt,
          amount: sales.amount,
          itemDetails: sales.itemDetails
        })
        .from(receipts)
        .innerJoin(sales, eq(receipts.saleId, sales.id))
        .where(eq(sales.customerId, customerId)),

        db.select()
        .from(orders)
        .where(eq(orders.customerId, customerId)),

        db.select()
        .from(odf)
        .where(eq(odf.customerId, customerId))
      ]);

      res.json({
        receipts: customerReceipts,
        orders: customerOrders,
        odf: customerOdfs
      });
    } catch (error) {
      console.error("Customer History Error:", error);
      res.status(500).json({ error: "Failed to fetch customer history" });
    }
  });

  // --- Search & Reporting Endpoints ---
  app.get("/api/search", authenticateToken, async (req, res) => {
    const { q } = req.query;
    if (!q || typeof q !== 'string') return res.status(400).json({ error: "Query string required" });

    const searchStr = `%${q}%`;
    try {
      const [stockResults, customerResults, receiptResults, orderResults] = await Promise.all([
        db.select().from(stock).where(or(ilike(stock.barcode, searchStr), ilike(stock.serialNumber, searchStr))),
        db.select().from(customers).where(or(ilike(customers.name, searchStr), ilike(customers.idNumber, searchStr))),
        // For serial numbers, we try exact match if q is numeric
        db.select().from(receipts).where(sql`CAST(${receipts.receiptSerialNumber} AS TEXT) ILIKE ${searchStr}`),
        db.select().from(orders).where(sql`CAST(${orders.orderNumber} AS TEXT) ILIKE ${searchStr}`)
      ]);

      res.json({
        stock: stockResults,
        customers: customerResults,
        receipts: receiptResults,
        orders: orderResults
      });
    } catch (error) {
      console.error("Search Error:", error);
      res.status(500).json({ error: "Search failed" });
    }
  });

  app.get("/api/reports/stock-weight", authenticateToken, checkPermission('reports', 'view'), async (req, res) => {
    const { category, subCategory } = req.query;
    try {
      // Build filters
      const conditions = [];
      if (category) conditions.push(eq(stock.category, category as string));
      if (subCategory) conditions.push(eq(stock.subCategory, subCategory as string));

      const results = await db.select({
        metalType: stock.metalType,
        stockType: stock.stockType,
        totalWeight: sql<number>`SUM(${stock.weightGrams})`.mapWith(Number)
      })
      .from(stock)
      .where(and(...conditions))
      .groupBy(stock.metalType, stock.stockType);

      // Format results for easier consumption
      const report: any = { Gold: {}, Silver: {} };
      results.forEach(row => {
        if (!row.metalType) return;
        const metal = row.metalType.charAt(0).toUpperCase() + row.metalType.slice(1).toLowerCase();
        if (report[metal]) {
          report[metal][row.stockType] = row.totalWeight;
        }
      });

      res.json(report);
    } catch (error) {
      console.error("Reporting Error:", error);
      res.status(500).json({ error: "Failed to generate weight report" });
    }
  });

  app.get("/api/reports/vat", authenticateToken, checkPermission('reports', 'view'), async (req, res) => {
    const { day, month, year } = req.query;
    try {
      const conditions = [];
      if (day) conditions.push(sql`EXTRACT(DAY FROM ${sales.datetime}) = ${day}`);
      if (month) conditions.push(sql`EXTRACT(MONTH FROM ${sales.datetime}) = ${month}`);
      if (year) conditions.push(sql`EXTRACT(YEAR FROM ${sales.datetime}) = ${year}`);

      const salesData = await db
        .select({
          date: sales.datetime,
          receiptNo: receipts.receiptSerialNumber,
          amountWithoutVat: sales.amount,
          vatAmount: sales.vat15,
          itemSold: sales.itemDetails,
          weight: sales.weight,
          metalType: sales.metalType,
          fineness: sales.fineness,
        })
        .from(sales)
        .leftJoin(receipts, eq(sales.id, receipts.saleId))
        .where(and(...conditions))
        .orderBy(sales.datetime);

      const formattedSales = salesData.map(s => {
        const amount = Number(s.amountWithoutVat || 0);
        const vat = Number(s.vatAmount || 0);
        return {
          ...s,
          totalAmount: (amount + vat).toFixed(2)
        };
      });

      const totalVatAmount = formattedSales.reduce((acc, curr) => acc + Number(curr.vatAmount), 0);

      res.json({
        data: formattedSales,
        total_vat_amount: totalVatAmount.toFixed(2)
      });
    } catch (error) {
      console.error("VAT Reporting Error:", error);
      res.status(500).json({ error: "Failed to generate VAT report" });
    }
  });

  // Settings Endpoints (Admin only)
  app.get("/api/settings", authenticateToken, async (req, res) => {
    try {
      const allSettings = await db.select().from(settings);
      res.json(allSettings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.get("/api/settings/:key", authenticateToken, async (req, res) => {
    try {
      const setting = await db.select().from(settings).where(eq(settings.key, req.params.key)).limit(1);
      if (setting.length === 0) return res.status(404).json({ error: "Setting not found" });
      res.json(setting[0]);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch setting" });
    }
  });

  app.put("/api/settings/:key", authenticateToken, async (req: any, res) => {
    if (req.user?.role !== 'Admin') return res.status(403).json({ error: "Admin access required" });
    
    const { value } = req.body;
    try {
      await db.update(settings)
        .set({ value, updatedAt: new Date() })
        .where(eq(settings.key, req.params.key));
      res.json({ message: `Setting ${req.params.key} updated successfully` });
    } catch (error) {
      res.status(500).json({ error: "Failed to update setting" });
    }
  });

  // --- ODF (Trade-ins) Endpoints ---
  app.post("/api/odf", authenticateToken, upload.single('image'), async (req, res) => {
    try {
      const { customerId, itemReservedRepair, comments, weight, metalType, fineness, amount } = req.body;
      const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

      const newOdf = await db.insert(odf).values({
        customerId: customerId ? parseInt(customerId) : null,
        itemReservedRepair,
        comments,
        weight: weight ? weight.toString() : null,
        metalType,
        fineness,
        amount: amount ? amount.toString() : null,
        imageUrl,
        date: new Date()
      }).returning();

      res.status(201).json({
        message: "ODF recorded successfully",
        odf_serial_number: newOdf[0].odfSerialNumber,
        odf: newOdf[0]
      });
    } catch (error) {
      console.error("ODF Error:", error);
      res.status(500).json({ error: "Failed to record Trade-in" });
    }
  });

  // --- Orders Endpoints ---
  app.get("/api/orders", authenticateToken, async (req, res) => {
    try {
      const allOrders = await db.select().from(orders).orderBy(orders.createdAt);
      res.json(allOrders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", authenticateToken, checkPermission('orders', 'create'), async (req, res) => {
    try {
      const { customerId, itemDescription, estimatedWeight } = req.body;
      const newOrder = await db.insert(orders).values({
        customerId: customerId ? parseInt(customerId) : null,
        itemDescription,
        estimatedWeight: estimatedWeight ? estimatedWeight.toString() : null,
        status: 'Pending'
      }).returning();

      res.status(201).json({
        message: "Order created successfully",
        order_number: newOrder[0].orderNumber,
        order: newOrder[0]
      });
    } catch (error) {
      console.error("Order Error:", error);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  // --- Order Finalization ---
  app.post("/api/orders/finalize", authenticateToken, checkPermission('sales', 'create'), async (req, res) => {
    const { orderNumber, weight, amount, paymentMode, chequeNumber, itemDetails, fineness, metalType } = req.body;

    try {
      const result = await db.transaction(async (tx) => {
        // 1. Fetch order
        const pendingOrders = await tx.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
        if (pendingOrders.length === 0) throw new Error("Order not found");
        if (pendingOrders[0].status === 'Finalized') throw new Error("Order already finalized");
        
        const order = pendingOrders[0];

        // 2. Calculate VAT (15%)
        const vat = Number(amount) * 0.15;

        // 3. Create Sale
        const newSale = await tx.insert(sales).values({
          customerId: order.customerId,
          stockId: null, // Manual order sale won't have a stock item
          paymentMode,
          chequeNumber,
          qty: 1,
          itemDetails: itemDetails || order.itemDescription,
          weight: weight.toString(),
          fineness,
          unitSalesPrice: amount.toString(),
          amount: amount.toString(),
          vat15: vat.toFixed(2),
          metalType,
          datetime: new Date()
        }).returning();

        // 4. Mark Order as Finalized
        await tx.update(orders)
          .set({ status: 'Finalized', updatedAt: new Date() })
          .where(eq(orders.orderNumber, orderNumber));

        return { saleId: newSale[0].id, orderNumber: order.orderNumber };
      });

      res.status(200).json({
        message: "Order finalized successfully",
        sales_id: result.saleId,
        order_number: result.orderNumber
      });
    } catch (error: any) {
      console.error("Order Finalization Error:", error);
      res.status(500).json({ error: error.message || "Failed to finalize order" });
    }
  });

  // --- Receipt PDF Generation ---
  app.get("/api/receipts/:saleId/pdf", authenticateToken, async (req, res) => {
    try {
      const { saleId } = req.params;
      const { generateReceiptPDF } = await import("./src/services/pdfService");
      
      const { doc } = await generateReceiptPDF(parseInt(saleId));
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=receipt-${saleId}.pdf`);
      
      doc.pipe(res);
      doc.end();
    } catch (error: any) {
      console.error("PDF Generation Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate PDF" });
    }
  });

  app.post("/api/receipts/:saleId/upload", authenticateToken, async (req, res) => {
    try {
      const { saleId } = req.params;
      const { generateReceiptPDF, getPDFBuffer } = await import("./src/services/pdfService");
      const { uploadReceiptToR2 } = await import("./src/services/storageService");
      
      // 1. Generate PDF
      const { doc, receipt } = await generateReceiptPDF(parseInt(saleId));
      const buffer = await getPDFBuffer(doc);
      
      // 2. Upload to R2
      const publicUrl = await uploadReceiptToR2(receipt.receiptSerialNumber.toString(), buffer);
      
      // 3. Save URL to receipts table
      await db.update(receipts)
        .set({ fileUrl: publicUrl })
        .where(eq(receipts.id, receipt.id));
        
      res.json({
        message: "Receipt uploaded successfully",
        public_url: publicUrl
      });
    } catch (error: any) {
      console.error("Receipt Upload Error:", error);
      res.status(500).json({ error: error.message || "Failed to upload receipt" });
    }
  });

  app.post("/api/receipts/:saleId/send", authenticateToken, async (req, res) => {
    const { saleId } = req.params;
    const { method } = req.body; // 'whatsapp', 'email', or 'both'

    try {
      const saleArr = await db.select().from(sales).where(eq(sales.id, parseInt(saleId))).limit(1);
      if (saleArr.length === 0) return res.status(404).json({ error: "Sale not found" });
      const sale = saleArr[0];

      const receiptArr = await db.select().from(receipts).where(eq(receipts.saleId, sale.id)).limit(1);
      if (receiptArr.length === 0) return res.status(404).json({ error: "Receipt not found. Generate it first." });
      const receipt = receiptArr[0];

      if (!receipt.fileUrl) return res.status(400).json({ error: "Receipt has not been uploaded to storage yet." });

      const customerArr = sale.customerId 
        ? await db.select().from(customers).where(eq(customers.id, sale.customerId)).limit(1)
        : [];
      const customer = customerArr[0];

      if (!customer) return res.status(404).json({ error: "Customer info required for sending receipt." });

      const results: any = {};

      if (method === 'whatsapp' || method === 'both') {
        if (customer.phoneNumber) {
          const { sendWhatsAppReceipt } = await import("./src/services/whatsappService");
          results.whatsapp = await sendWhatsAppReceipt(customer.phoneNumber, receipt.fileUrl, receipt.receiptSerialNumber.toString());
        } else {
          results.whatsapp = "Phone number missing for customer";
        }
      }

      if (method === 'email' || method === 'both') {
        if (customer.email) {
          const { sendEmailReceipt } = await import("./src/services/emailService");
          results.email = await sendEmailReceipt(customer.email, customer.name, receipt.fileUrl, receipt.receiptSerialNumber.toString());
        } else {
          results.email = "Email missing for customer";
        }
      }

      res.json({ message: "Send operations completed", results });
    } catch (error: any) {
      console.error("Send Error:", error);
      res.status(500).json({ error: error.message || "Failed to send receipt" });
    }
  });

  // --- ODF PDF Generation & Sending ---
  app.get("/api/odf/:id/pdf", authenticateToken, async (req, res) => {
    try {
      const odfId = parseInt(req.params.id);
      const { generateODFPDF } = await import("./src/services/pdfService");
      
      const { doc } = await generateODFPDF(odfId);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=odf-${odfId}.pdf`);
      
      doc.pipe(res);
      doc.end();
    } catch (error: any) {
      console.error("ODF PDF Generation Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate ODF PDF" });
    }
  });

  app.post("/api/odf/:id/upload", authenticateToken, async (req, res) => {
    try {
      const odfId = parseInt(req.params.id);
      const { generateODFPDF, getPDFBuffer } = await import("./src/services/pdfService");
      const { uploadODFToR2 } = await import("./src/services/storageService");
      
      const { doc, odfRecord } = await generateODFPDF(odfId);
      const buffer = await getPDFBuffer(doc);
      
      const publicUrl = await uploadODFToR2(odfRecord.odfSerialNumber.toString(), buffer);
      
      await db.update(odf)
        .set({ fileUrl: publicUrl })
        .where(eq(odf.id, odfId));
        
      res.json({
        message: "ODF uploaded successfully",
        public_url: publicUrl
      });
    } catch (error: any) {
      console.error("ODF Upload Error:", error);
      res.status(500).json({ error: error.message || "Failed to upload ODF" });
    }
  });

  app.post("/api/odf/:id/send", authenticateToken, async (req, res) => {
    const odfId = parseInt(req.params.id);
    const { method } = req.body; // 'whatsapp', 'email', or 'both'

    try {
      const odfArr = await db.select().from(odf).where(eq(odf.id, odfId)).limit(1);
      if (odfArr.length === 0) return res.status(404).json({ error: "ODF record not found" });
      const record = odfArr[0];

      if (!record.fileUrl) return res.status(400).json({ error: "ODF document has not been uploaded to storage yet." });

      const customerArr = record.customerId 
        ? await db.select().from(customers).where(eq(customers.id, record.customerId)).limit(1)
        : [];
      const customer = customerArr[0];

      if (!customer) return res.status(404).json({ error: "Customer info required for sending ODF." });

      const results: any = {};

      if (method === 'whatsapp' || method === 'both') {
        if (customer.phoneNumber) {
          const { sendWhatsAppODF } = await import("./src/services/whatsappService");
          results.whatsapp = await sendWhatsAppODF(customer.phoneNumber, record.fileUrl, record.odfSerialNumber.toString());
        } else {
          results.whatsapp = "Phone number missing for customer";
        }
      }

      if (method === 'email' || method === 'both') {
        if (customer.email) {
          const { sendEmailODF } = await import("./src/services/emailService");
          results.email = await sendEmailODF(customer.email, customer.name, record.fileUrl, record.odfSerialNumber.toString());
        } else {
          results.email = "Email missing for customer";
        }
      }

      res.json({ message: "ODF sending operations completed", results });
    } catch (error: any) {
      console.error("ODF Send Error:", error);
      res.status(500).json({ error: error.message || "Failed to send ODF" });
    }
  });

  // --- Reports & Audit Endpoints ---
  app.get("/api/reports/vat", authenticateToken, async (req: any, res) => {
    const { day, month, year } = req.query;
    try {
      let conditions = [];
      if (year) conditions.push(sql`EXTRACT(YEAR FROM ${sales.createdAt}) = ${year}`);
      if (month) conditions.push(sql`EXTRACT(MONTH FROM ${sales.createdAt}) = ${month}`);
      if (day) conditions.push(sql`EXTRACT(DAY FROM ${sales.createdAt}) = ${day}`);

      const reportData = await db.select({
        saleId: sales.id,
        receiptNo: receipts.receiptSerialNumber,
        itemDetails: sales.itemDetails,
        weight: sales.weight,
        amountExclVat: sales.amount,
        createdAt: sales.createdAt
      })
      .from(sales)
      .leftJoin(receipts, eq(sales.id, receipts.saleId))
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(sales.id);

      const calculatedData = reportData.map(row => {
        const amount = parseFloat(row.amountExclVat || "0");
        const vat = amount * 0.15;
        return {
          ...row,
          vatAmount: vat.toFixed(2),
          total: (amount + vat).toFixed(2)
        };
      });

      const totalVat = calculatedData.reduce((sum, row) => sum + parseFloat(row.vatAmount), 0);

      res.json({ data: calculatedData, summary: { totalVat: totalVat.toFixed(2) } });
    } catch (error) {
      console.error("VAT Report Error:", error);
      res.status(500).json({ error: "Failed to fetch VAT report" });
    }
  });

  app.get("/api/receipts", authenticateToken, async (req, res) => {
    try {
      const allReceipts = await db.select({
        id: receipts.id,
        saleId: receipts.saleId,
        receiptNo: receipts.receiptSerialNumber,
        fileUrl: receipts.fileUrl,
        createdAt: receipts.createdAt,
        customerName: customers.name,
        totalAmount: sales.amount
      })
      .from(receipts)
      .innerJoin(sales, eq(receipts.saleId, sales.id))
      .innerJoin(customers, eq(sales.customerId, customers.id))
      .orderBy(receipts.createdAt);

      res.json(allReceipts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch receipts" });
    }
  });

  app.get("/api/audit-logs", authenticateToken, async (req: any, res) => {
    if (req.user?.role !== 'Admin') return res.status(403).json({ error: "Admin access required" });
    try {
      const logs = await db.select({
        id: auditLogs.id,
        userId: auditLogs.userId,
        username: users.username,
        action: auditLogs.actionType,
        details: auditLogs.details,
        createdAt: auditLogs.timestamp
      })
      .from(auditLogs)
      .leftJoin(users, eq(auditLogs.userId, users.id))
      .orderBy(auditLogs.timestamp);

      res.json(logs);
    } catch (error) {
      console.error("Audit Logs Error:", error);
      res.status(500).json({ error: "Failed to fetch audit logs" });
    }
  });

  // --- ODF (Trade-ins) Endpoints ---
  app.get("/api/odf", authenticateToken, async (req, res) => {
    try {
      const allOdf = await db.select({
        id: odf.id,
        customerId: odf.customerId,
        customerName: customers.name,
        metalType: odf.metalType,
        fineness: odf.fineness,
        weight: odf.weight,
        amount: odf.amount,
        itemReservedRepair: odf.itemReservedRepair,
        comments: odf.comments,
        imageUrl: odf.imageUrl,
        createdAt: odf.createdAt
      })
      .from(odf)
      .innerJoin(customers, eq(odf.customerId, customers.id))
      .orderBy(odf.createdAt);
      res.json(allOdf);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch ODF records" });
    }
  });

  app.post("/api/odf", authenticateToken, upload.single('image'), async (req: any, res) => {
    const { customerId, metalType, fineness, weight, amount, itemReservedRepair, comments, createdAt } = req.body;
    let imageUrl = null;

    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    }

    try {
      const newOdf = await db.insert(odf).values({
        customerId: parseInt(customerId),
        metalType,
        fineness,
        weight,
        amount,
        itemReservedRepair,
        comments,
        imageUrl,
        date: createdAt ? new Date(createdAt) : new Date(),
        createdAt: createdAt ? new Date(createdAt) : new Date()
      }).returning();

      res.status(201).json(newOdf[0]);
    } catch (error) {
      console.error("ODF Creation Error:", error);
      res.status(500).json({ error: "Failed to create ODF record" });
    }
  });

  // --- Orders Endpoints ---
  app.get("/api/orders", authenticateToken, async (req, res) => {
    try {
      const allOrders = await db.select({
        id: orders.id,
        customerId: orders.customerId,
        customerName: customers.name,
        itemDescription: orders.itemDescription,
        status: orders.status,
        finalWeight: orders.finalWeight,
        finalPrice: orders.finalPrice,
        createdAt: orders.createdAt
      })
      .from(orders)
      .innerJoin(customers, eq(orders.customerId, customers.id))
      .orderBy(orders.createdAt);
      res.json(allOrders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", authenticateToken, async (req, res) => {
    const { customerId, itemDescription, createdAt } = req.body;
    try {
      const newOrder = await db.insert(orders).values({
        customerId: parseInt(customerId),
        itemDescription,
        status: 'Pending',
        createdAt: createdAt ? new Date(createdAt) : new Date()
      }).returning();
      res.status(201).json(newOrder[0]);
    } catch (error) {
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.post("/api/orders/:id/finalize", authenticateToken, async (req: any, res) => {
    const { finalWeight, finalPrice, paymentMode } = req.body;
    const orderId = parseInt(req.params.id);

    try {
      await db.transaction(async (tx: any) => {
        const [order] = await tx.select().from(orders).where(eq(orders.id, orderId)).limit(1);
        if (!order) throw new Error("Order not found");

        await tx.update(orders)
          .set({ status: 'Completed', finalWeight, finalPrice })
          .where(eq(orders.id, orderId));

        await tx.insert(sales).values({
          customerId: order.customerId,
          barcode: `ORDER-${orderId}`,
          amount: finalPrice.toString(),
          weight: finalWeight.toString(),
          paymentMode,
          itemDetails: `Finalized Order: ${order.itemDescription}`,
          qty: 1,
          unitSalesPrice: finalPrice.toString()
        });
      });

      res.json({ message: "Order finalized and sale created" });
    } catch (error) {
      console.error("Order Finalization Error:", error);
      res.status(500).json({ error: "Failed to finalize order" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Error starting server:", err);
  process.exit(1);
});
